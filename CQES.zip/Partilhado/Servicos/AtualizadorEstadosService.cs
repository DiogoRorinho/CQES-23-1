// Implementação do serviço de atualização de estados
using Microsoft.Data.Sqlite;
using GestorEventos.Partilhado;

namespace GestorEventos.Partilhado.Servicos
{
    public class AtualizadorEstadosService : IAtualizadorEstados
    {
        private readonly string connectionString;

        public AtualizadorEstadosService()
        {
            connectionString = ConfiguracaoAplicacao.ObterConnectionString();
        }

        public void AtualizarEstados()
        {
            AtualizarEventos();
            AtualizarInscricoes();
        }

        private void AtualizarEventos()
        {
            using SqliteConnection connection = new SqliteConnection(connectionString);
            connection.Open();

            string sql = @"
                UPDATE eventos
                SET estado = 'terminado'
                WHERE estado = 'ativo'
                  AND date(data) < date('now','localtime');
            ";

            using SqliteCommand command = new SqliteCommand(sql, connection);
            command.ExecuteNonQuery();
        }

        private void AtualizarInscricoes()
        {
            using SqliteConnection connection = new SqliteConnection(connectionString);
            connection.Open();

            string sql = @"
                UPDATE inscricoes
                SET estado = 'terminada'
                WHERE estado = 'ativa'
                  AND id_evento IN (
                      SELECT id
                      FROM eventos
                      WHERE estado = 'terminado'
                  );
            ";

            using SqliteCommand command = new SqliteCommand(sql, connection);
            command.ExecuteNonQuery();
        }
    }
}